﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MOTORES_2._0
{
    internal class Program
    {
        static double[] motor;

        static void lancar()
        {
            int posicao = 0;

            Console.WriteLine("Opção 'Lançar Valor' Selecionda\n");
            Console.WriteLine("Escolha o Motor (1...15): ");
            posicao = int.Parse(Console.ReadLine());

            while (posicao < 1 || posicao > 15)
            {
                Console.WriteLine("Escolha o Motor Novamente (1...15): ");
                posicao = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("\nAtribua um Valor Para o Motor {0} (R$): ", posicao);
            motor[posicao - 1] += double.Parse(Console.ReadLine());

            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
            Console.ReadKey();
        }
        static void mostrar()
        {
            double total = 0;
            
            Console.WriteLine("Opção 'Mostrar Valores' Selecionda\n");
            Console.WriteLine("\n  MOTORES      VALORES\n");
            Console.WriteLine("-------------------------");

            for (int posicao = 0; posicao < 15; posicao++)
            {
                Console.WriteLine("Motor:{0: 00}  Valor: {1}", posicao + 1, motor[posicao].ToString("C"));
            }

            total = motor.Sum();

            Console.WriteLine("-------------------------");
            Console.WriteLine("\nTotal: {0}", total.ToString("C"));
            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
            Console.ReadKey();
        }
        static void maiorValor()
        {
            double maior = 0;
            double posicaoMaior = 0;

            Console.WriteLine("Opção 'Mostrar Motor com Maior Gasto' Selecionda\n");

            if (motor.Sum() == 0)
            {
                Console.WriteLine("Até o Momento, Não Houve Gasto em Nenhum Motor!");
            }
            else 
            {
                for (int i = 0; i < 15; i++)
                {
                    if (motor[i] > maior)
                    {
                        maior = motor[i];
                        posicaoMaior = i;
                    }
                }

                Console.WriteLine("O Motor que Teve Mais Gastos foi:");
                Console.WriteLine("O Motor: {0:00}", (posicaoMaior +1));
                Console.WriteLine("No Valor de: {0}", maior.ToString("C"));
            }

            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
            Console.ReadKey(); 
        }
        static void menorValor()
        {
            double menor = double.PositiveInfinity;
            double posicaoMenor = 0;

            Console.WriteLine("Opção 'Mostrar Motor com Menor Gasto' Selecionda\n");

            if (motor.Sum() == 0)
            {
                Console.WriteLine("Até o Momento, Não Houve Gasto em Nenhum Motor!");
            }
            else
            {
                for (int i = 0; i < 15; i++)
                {
                    if(motor[i] != 0)
                    {
                        if (motor[i] < menor)
                        {
                            menor = motor[i];
                            posicaoMenor = i;
                        }
                    }
                }

                Console.WriteLine("O Motor que Teve Menos Gastos foi:");
                Console.WriteLine("O Motor: {0:00}", (posicaoMenor + 1));
                Console.WriteLine("No Valor de: {0}", menor.ToString("C"));
            }

            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
            Console.ReadKey();
        }
        static void sobre()
        {
            Console.WriteLine("Opção 'Sobre' Selecionda\n");
            Console.WriteLine("Desenvolvedor: Ronivy de Melo Soares ");
            Console.WriteLine("Curso: CTA 171 ");
            Console.WriteLine("Versão: 2.0.1 ");
            Console.WriteLine("Data: 07/22");

            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            motor = new double[15];
            int opc = 0;
            
            do
            {
                Console.Clear();
                Console.WriteLine("---------------MENU---------------");
                Console.WriteLine("\nO. Sair");
                Console.WriteLine("1. Lançar Valor");
                Console.WriteLine("2. Mostrar Valores");
                Console.WriteLine("3. Mostrar Motor com Maior Gasto");
                Console.WriteLine("4. Mostrar Motor com Menor Gasto");
                Console.WriteLine("5. Sobre");
                Console.Write("\nEscolha uma Opção: ");
                opc = int.Parse(Console.ReadLine());

                while (opc < 0 || opc > 5)
                {
                    Console.Write("\nOpção Inválida, Digite Novamente: ");
                    opc = int.Parse(Console.ReadLine());
                }
                Console.Clear();

                switch (opc)
                {
                    case 1:
                        {
                            lancar();
                            break;
                        }
                    case 2:
                        {
                            mostrar();
                            break;
                        }
                    case 3:
                        {
                            maiorValor();
                            break;
                        }
                    case 4:
                        {
                           menorValor();
                            break;
                        }
                    case 5:
                        {
                            sobre();
                            break;
                        }
                }
            }
            while (opc != 0);
        }
    }
}
